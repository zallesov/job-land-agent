---
name: wellfound-scraper
description: Knows how to invoke the WellFound scraper script with location parameters. Use when running the WellFound scraping step of the daily pipeline.
---

# WellFound Scraper

## Script

```
python3 scripts/scrape_wellfound.py
```

## Parameters

- `--location <preset>` — named preset: `berlin` or `spain`
- `--headless` — always pass this for unattended runs
- `--date <YYYY-MM-DD>` — optional, defaults to today
- `--skip-enrich` — skip detail page enrichment (faster but less data)
- `--max-jobs <N>` — limit number of jobs to scrape (0 = all)

## Output

Writes partial JSON to:
```
outputs/wellfound/runs/wellfound_jobs_live_<date>_<location_slug>.json
```

## How It Works

WellFound is a React SPA — search state is client-side. The scraper:
1. Navigates to `/jobs` — user's saved search auto-loads
2. Changes location via UI interaction (clicks location button, types new location, selects from dropdown)
3. Scrolls to trigger infinite scroll and load all results
4. Collects job cards from DOM (company cards contain nested job listings)
5. Enriches each job by visiting its detail page

### Playwright MCP Over CDP (Alternative Approach)

When the standalone Playwright script hits CAPTCHAs or bot detection, use Playwright MCP pointed at the local Chrome CDP endpoint instead. This inherits the full Chrome profile (cookies, logins, saved searches) and avoids detection:

```python
# Config in config.yaml (already wired):
# playwright:
#   command: "npx"
#   args:
#     - "-y"
#     - "@playwright/mcp"
#     - "--cdp-endpoint"
#     - "http://localhost:9222"
```

Key `mcp_playwright_*` tools used:
- `mcp_playwright_browser_navigate` — navigate to `/jobs`
- `mcp_playwright_browser_snapshot` — inspect page state
- `mcp_playwright_browser_evaluate` — execute JS for data extraction / scrolling
- `mcp_playwright_browser_wait_for` — wait for lazy-loaded content
- `mcp_playwright_browser_click` — if location/filter changes needed

### Infinite Scroll Pattern

WellFound lazy-loads jobs on scroll. Counting confirmed: first load shows a subset, each scroll-to-bottom loads more. 2+ iterations typically needed:

```js
// Scroll and count:
() => window.scrollTo(0, document.body.scrollHeight)
// Wait 2s for lazy load, then count:
() => { const links = document.querySelectorAll('a[href*="/jobs/"]'); return links.length; }
```

Typical progression: ~90 → ~130 → 142 (full load). Stop when count stabilizes across two consecutive scrolls.

## Pre-Flight: Chrome Must Be Running

Before any interactive WellFound browser session, verify local Chrome is alive on `localhost:9222`:

```bash
curl -s http://localhost:9222/json/version || echo "NOT_RUNNING"
```

If `NOT_RUNNING`, tell Zall to run `~/start-chrome.sh`. The `browser_navigate` tool silently falls back to Browserbase cloud (no profile persistence, no logins) when Chrome isn't running — don't let it.

## Auth

Browser profile at `~/.interviews-browser-profile` must be pre-authenticated with WellFound.
If not logged in, the `/jobs` page shows generic content without saved searches.

## Google One Tap Auto-Auth

WellFound triggers Google One Tap sign-in via an OAuth iframe (`wellfound.com/auth/google_one_tap`) when Chrome has a logged-in Google session. This redirects to `accounts.google.com/signin/oauth/id`. The user can either complete the sign-in (persists across sessions) or skip it — the jobs page works either way, but saved searches/settings require auth.

## Example Invocations

```bash
python3 scripts/scrape_wellfound.py --location berlin --headless
python3 scripts/scrape_wellfound.py --location spain --headless
python3 scripts/scrape_wellfound.py --location berlin --headless --skip-enrich --max-jobs 10
```

## Success Check

Exit code 0. Stdout contains JSON with `count` > 0.

## Known Locations

| Preset   | Search Query       |
|----------|--------------------|
| `berlin` | Berlin, Germany    |
| `spain`  | Spain              |
