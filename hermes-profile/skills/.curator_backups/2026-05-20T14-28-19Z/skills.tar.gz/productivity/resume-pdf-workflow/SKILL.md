---
name: resume-pdf-workflow
description: Generate, revise, and verify resume/CV markdown and PDFs for job applications, prioritizing ATS-safe consistency over style-preserving image edits.
created_by: agent
author: Hermes Agent
version: 1.0.0
license: MIT
category: productivity
---

# Resume PDF Workflow

Use this skill for resume/CV work when the user wants to:
- turn source material into final resume wording
- keep a canonical markdown source for future tailoring
- generate a PDF for applications
- update an existing PDF while preserving style when possible

This skill is especially appropriate for Zall-style workflows where the resume is iterated in markdown first and then rendered to PDF.

## Core rule

Prefer a clean, deterministic PDF generated from the markdown source over image-editing an older PDF whenever consistency, ATS-readability, or font/layout reliability matters.

Style-preserving PDF editing is optional and secondary.

## Recommended workflow

1. Establish the canonical source files
   - Keep one markdown file as the source of truth
   - Keep one PDF as the current application artifact
   - Confirm the exact filenames/paths and reuse them consistently

2. Produce final-ready copy, not planning notes
   - If the user asks for CV content, draft the exact wording intended for the PDF
   - Keep recruiter-facing language clean and concise
   - Use a dedicated skills section for ATS

3. If the user requests PDF generation, choose the rendering path deliberately
   - First choice: generate a fresh PDF from markdown with a single consistent font family and deterministic layout
   - Second choice: use an image-editing PDF tool only when the original visual design is worth the risk and the user explicitly wants style preservation

4. Verify the output
   - Confirm the file exists
   - Confirm page count
   - Extract text to sanity-check readability and corruption
   - If the PDF is inconsistent or garbled, do not present it as application-ready

## Using nano-pdf (style-preserving path)

nano-pdf is an image-editing workflow, not a real text-layout editor.
It:
- renders PDF pages to images
- sends them to Gemini image generation/editing
- rehydrates the result into PDF pages with OCR

### Implications
- Requires `GEMINI_API_KEY`
- Requires working quota/billing for Gemini image generation
- Can introduce garbling, OCR damage, font inconsistency, and layout drift
- Should be treated as best-effort, not deterministic production tooling

### When to use it
Use nano-pdf only if all of the following are true:
- user strongly wants the original PDF style preserved
- billing/quota is available
- the result will be visually inspected and text-verified afterward

### Operational notes
- Remove inline comments from `GEMINI_API_KEY=...` lines in `.env`; tools that parse raw env values may treat trailing comments as part of the key
- If image-loading errors appear (`image file is truncated`), a pragmatic workaround is enabling `PIL.ImageFile.LOAD_TRUNCATED_IMAGES = True` in the nano-pdf runtime
- Lowering render resolution can help stability if high-resolution page editing fails

## Deterministic PDF generation path

When consistency matters, generate the PDF directly from markdown.

Requirements:
- one font family across all pages
- tight but readable spacing
- 2-page target for senior candidates unless the user explicitly wants otherwise
- ATS-friendly single-column layout
- predictable section order

Suggested section order:
1. Name / contact
2. Headline
3. Summary
4. Core Skills
5. Professional Experience
6. Additional Experience (optional)
7. Education
8. Selected Technologies (optional)

## Verification checklist

Before calling the resume finished:
- file exists
- page count is correct
- text extraction is clean enough to confirm legibility
- no page-specific font mismatch
- no obvious OCR corruption
- markdown source and PDF reflect the same content

## User-specific guidance captured from this session

For Zall:
- when asked for CV content, provide the exact final wording intended for the PDF, not just a master-plan document
- keep one canonical markdown source and one canonical PDF for job applications
- if style preservation conflicts with consistency, choose the regenerated ATS-safe PDF

## References

See `references/nano-pdf-notes.md` for session-specific notes on nano-pdf behavior, quota requirements, and verification lessons.
